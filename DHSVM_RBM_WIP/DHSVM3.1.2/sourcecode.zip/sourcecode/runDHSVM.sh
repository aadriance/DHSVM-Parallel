#!/bin/bash

export NUM_RUNS=$1

sbatch dhsvm.sbatch