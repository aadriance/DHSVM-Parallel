class AatError extends Exception {
	public AatError(String s) { super(s); }
}
