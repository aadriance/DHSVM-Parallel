#!/bin/bash

sbatch dhsvm.sbatch