#!/bin/bash

module load openmpi/gcc/64/1.10.3
make -f makefile_for_mpi